#include <iostream>
#include <string>
#include <regex>
#include <algorithm>
#include <memory>
#include <exception>
#include <stdexcept>
#include <thread>

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#include <cstring>

#include "filemanager.h"

class Server {
public:
    Server(int domain, int type, int port);

    Server(const Server &server) = delete;
    Server& operator=(const Server &server) = delete;

    Server(Server &&server) = default;
    Server& operator=(Server&& server) = default;

    ~Server();

    void SendMessage(const char *data);

    int CreateListener();
    [[nodiscard]] int GetListener() const;

    bool BindAddress();
    bool BindAddress(const sockaddr_in &address);
    sockaddr_in GetAddress() const;

    int AcceptSocket();
    int GetSocket() const;

    void Close() const;

    int GetDomain() const;
    int GetType() const;
    int GetPort() const;
private:
    sockaddr_in address_{};
    int listener_{};
    int server_socket_{};
    int domain_;
    int type_;
    int port_;
};

Server::Server(int domain, int type, int port) :
        domain_(domain), type_(type), port_(port)
{}

Server::~Server() {
    close(server_socket_);
}

void Server::SendMessage(const char *data) {
    send(server_socket_, data, strlen(data), 0);
}

int Server::CreateListener() {
    listener_ = socket(domain_, type_, 0);
    if (listener_ < 0) {
        std::cerr << "Error: socket" << std::endl;
        return -1;
    }
    return listener_;
}

int Server::GetListener() const {
    return listener_;
}

bool Server::BindAddress() {
    address_.sin_family = domain_;
    address_.sin_port = htons(port_);
    address_.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(listener_, (sockaddr*)&address_, sizeof(address_)) < 0) {
        std::cerr << "Error: bind" << std::endl;
        return false;
    }
    return true;
}

bool Server::BindAddress(const sockaddr_in &address) {
    address_.sin_family = address.sin_family;
    address_.sin_port = address.sin_port;
    address_.sin_addr.s_addr = address.sin_addr.s_addr;
    if (bind(listener_, (sockaddr*)&address_, sizeof(address_)) < 0) {
        std::cerr << "Error: bind" << std::endl;
        return false;
    }
    return true;
}

sockaddr_in Server::GetAddress() const {
    return address_;
}

int Server::AcceptSocket() {
    listen(listener_, 1);
    server_socket_ = accept(listener_, NULL, NULL);
    if (server_socket_ < 0) {
        std::cerr << "Error: accept" << std::endl;
        return -1;
    }
    return server_socket_;
}

int Server::GetSocket() const {
    return server_socket_;
}

void Server::Close() const
{
    close(server_socket_);
}

int Server::GetDomain() const
{
    return domain_;
}

int Server::GetType() const
{
    return type_;
}

int Server::GetPort() const
{
    return port_;
}

bool CheckInput(std::string &str) {

    auto regex_exp = std::regex("[0-9]+");

    if (!std::regex_match(str, regex_exp)) {
        return false;
    }

    constexpr int kStringSize = 64;
    if (str.size() > kStringSize) {
        str.resize(kStringSize);
    }

    std::sort(rbegin(str), rend(str));

    constexpr int kStep = 3;
    for (int i = 0; i < str.size(); i += kStep) {
        str.replace(i, 1, "KB");
    }

    return true;
}

int CountSum(std::string &str) {
    int sum = 0;
    constexpr int kStartPosition = 2;
    constexpr int kStep = 3;

    for (int i = kStartPosition; i < str.size(); i+=kStep) {
        sum += (str[i] - '0');
    }

    return sum;
}

void Produce(FileManager<std::string> &manager) {
    std::string str;
    while (std::cin >> str) {

        if (!CheckInput(str)) {
            continue;
        }

        // push string in buffer
        manager.Push(str);
    }
}

void Consume(FileManager<std::string> &manager) {
    constexpr int kPort = 3425;
    Server server(AF_INET, SOCK_STREAM, kPort);
    server.CreateListener();

    if (!server.BindAddress()) {
        return;
    }

    server.AcceptSocket();

    std::string str;
    int sum = 0;
    try {
        while (true) {
            // pop string from buffer
            str = manager.Pop();

            std::cout << "Get data " << str << std::endl;

            sum = 0;
            sum = CountSum(str);

            // send sum
            server.SendMessage(std::to_string(sum).c_str());

        }
    } catch (std::runtime_error &error) {
        std::cout << error.what() << std::endl;
        server.Close();
    }
}

int main() {
    FileManager<std::string> manager("input.txt");
    std::thread produce_thread(Produce, std::ref(manager));
    std::thread consume_thread(Consume, std::ref(manager));

    produce_thread.join();
    consume_thread.join();

    return 0;
}
