#include <netinet/in.h>

#include <iostream>
#include <cstring>
#include <string>

#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>


class Client {
public:
    Client(int domain, int type, int port);

    Client(const Client &client) = delete;
    Client& operator=(const Client &client) = delete;

    Client(Client &&client) = default;
    Client& operator=(Client &&client) = default;

    ~Client();

    int GetMessage(char *data, int size);

    int CreateSocket();
    int GetSocket() const;

    bool ConnectToAddress();
    bool ConnectToAddress(sockaddr_in &address);
    sockaddr_in GetAddress() const;

    int AcceptSocket();

    int GetDomain() const;
    int GetType() const;
    int GetPort() const;
private:
    sockaddr_in address_;
    int listener_;
    int socket_client_;
    int domain_;
    int type_;
    int port_;
};

Client::Client(int domain, int type, int port) :
        domain_(domain), type_(type), port_(port)
{}

Client::~Client() {
    close(socket_client_);
}

int Client::GetMessage(char *data, int size) {
    return recv(socket_client_, (void *)data, size, 0);
}

int Client::CreateSocket() {
    socket_client_ = socket(domain_, type_, 0);
    if(socket_client_ < 0) {
        std::cerr << "Error: socket" << std::endl;
        return 1;
    }
    return socket_client_;
}

int Client::GetSocket() const {
    return socket_client_;
}

bool Client::ConnectToAddress() {
    address_.sin_family = domain_;
    address_.sin_port = htons(port_); // или любой другой порт...
    address_.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if(connect(socket_client_, (sockaddr *)&address_, sizeof(address_)) < 0) {
        std::cerr << "Error: connect" << std::endl;
        return false;
    }
    return true;
}

bool Client::ConnectToAddress(sockaddr_in &address)
{
    address_.sin_family = address.sin_family;
    address_.sin_port = address.sin_port;
    address_.sin_addr.s_addr = address.sin_addr.s_addr;

    if(connect(socket_client_, (sockaddr *)&address_, sizeof(address_)) < 0) {
        std::cerr << "Error: connect" << std::endl;
        return false;
    }
    return true;
}

sockaddr_in Client::GetAddress() const {
    return address_;
}

int Client::GetDomain() const
{
    return domain_;
}

int Client::GetType() const
{
    return type_;
}

int Client::GetPort() const
{
    return port_;
}

int main() {
    constexpr int kMessageSize = 96;
    char message[kMessageSize];
    constexpr int port = 3425;
    Client client(AF_INET, SOCK_STREAM, port);
    client.CreateSocket();

    if (!client.ConnectToAddress()) {
        return 1;
    }

    constexpr int kMinimumSize = 2;
    constexpr int kMultiplicityNumber = 32;
    while (true) {
        int result = client.GetMessage(message, kMessageSize);

        if (result == 0) {
            break;
        }

        if (strlen(message) > kMinimumSize && std::stoi(message) % kMultiplicityNumber == 0) {
            std::cout << "Get data " << message << std::endl;
        } else {
            std::cout << "Error" << std::endl;
        }
    }

    return 0;
}
