#ifndef BUFFER_H
#define BUFFER_H

#include <string>
#include <fstream>
#include <mutex>
#include <condition_variable>


template <typename T>
class Buffer {
public:
    Buffer(const std::string &filename);

    Buffer(const Buffer &manager) = delete;
    Buffer& operator=(const Buffer &manager) = delete;

    Buffer(Buffer &&manager) = default;
    Buffer& operator=(Buffer &&manager) = default;

    ~Buffer();

    void Push(T value);
    T Pop();
    bool Empty() const;
private:
    bool empty_cond;
    std::fstream bufstream;
    std::string fn;
    std::mutex queue_mtx;
    std::condition_variable queue_var;
};


template<typename T>
Buffer<T>::Buffer(const std::string &filename) :
        fn(filename), empty_cond(true)
{
}

template<typename T>
Buffer<T>::~Buffer()
{
    bufstream.close();
}

template<typename T>
void Buffer<T>::Push(T value) {
    std::unique_lock<std::mutex> locker(queue_mtx);
    queue_var.wait(locker, [this]{return empty_cond;});
    bufstream.open(fn, std::fstream::out);
    bufstream << value;
    empty_cond = false;
    bufstream.close();
    queue_var.notify_one();
}


template<typename T>
T Buffer<T>::Pop() {
    std::unique_lock<std::mutex> locker(queue_mtx);
    queue_var.wait(locker, [this]{return !empty_cond;});
    T value;
    bufstream.open(fn, std::fstream::in);
    bufstream >> value;
    bufstream.close();
    bufstream.open(fn, std::fstream::out);
    bufstream.close();
    empty_cond = true;
    return value;
}

template<typename T>
bool Buffer<T>::Empty() const {
    return empty_cond;
}

#endif // BUFFER_H
