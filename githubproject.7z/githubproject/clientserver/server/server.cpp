#include "buffer.h"

#include <iostream>
#include <string>
#include <algorithm>
#include <thread>

#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#include <cstring>



class Server {
public:
    Server(int domain, int type, int port);

    ~Server();

    void SendMessage(const char *data);

    int CreateListener();
    [[nodiscard]] int GetListener() const;

    bool BindAddress();
    bool BindAddress(const sockaddr_in &address);

    int AcceptSocket();
    int GetSocket() const;

    void Close() const;

private:
    sockaddr_in sr_address{};
    int listener_{};
    int serv_sock{};
    int sr_domain;
    int sr_type;
    int sr_port;
};

Server::Server(int domain, int type, int port) :
        sr_domain(domain), sr_type(type), sr_port(port)
{}

Server::~Server() {
    close(serv_sock);
}

void Server::SendMessage(const char *data) {
    send(serv_sock, data, strlen(data), 0);
}

int Server::CreateListener() {
    listener_ = socket(sr_domain, sr_type, 0);
    if (listener_ < 0) {
        std::cerr << "Error: socket" << std::endl;
        return -1;
    }
    return listener_;
}

int Server::GetListener() const {
    return listener_;
}

bool Server::BindAddress() {
    sr_address.sin_family = sr_domain;
    sr_address.sin_port = htons(sr_port);
    sr_address.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(listener_, (sockaddr*)&sr_address, sizeof(sr_address)) < 0) {
        std::cerr << "Error: bind" << std::endl;
        return false;
    }
    return true;
}

bool Server::BindAddress(const sockaddr_in &address) {
    sr_address.sin_family = address.sin_family;
    sr_address.sin_port = address.sin_port;
    sr_address.sin_addr.s_addr = address.sin_addr.s_addr;
    if (bind(listener_, (sockaddr*)&sr_address, sizeof(sr_address)) < 0) {
        std::cerr << "Error: bind" << std::endl;
        return false;
    }
    return true;
}

int Server::AcceptSocket() {
    listen(listener_, 1);
    serv_sock = accept(listener_, NULL, NULL);
    if (serv_sock < 0) {
        std::cerr << "Error: accept" << std::endl;
        return -1;
    }
    return serv_sock;
}

void Server::Close() const
{
    close(serv_sock);
}

bool CheckInput(std::string &str) {
    bool us = true;
    std::string newstr1 = "";
    std::cout << std::endl << "input data: " << str << std::endl;
    for (int i=0; i<str.size(); i++){
        if (!((str[i]<='9')&&(str[i]>='0')))
            us = false;
    }
    if (us == false)
        std::cout << "uncorrect input, it must contain only digits\n";

    if (str.size() > 64) {
        str.resize(64);
    }
    if(us){
        std :: sort(rbegin(str), rend(str));
        std::cout << "input data after sorting: " << str << std::endl;
        char *newstr;
        newstr= new char [128];
        int n=0;
        for (int i = 0; i < str.size(); i++) {
            if (((str[i]-'0')%2)==0){
                newstr[n]='K';
                newstr[n+1]='B';
                n+=2;
            }
            else{
                newstr[n]=str[i];
                n++;
            }
        }
        newstr[strlen(newstr)]='\0';
        for (int i =0; i<strlen(newstr); i++)
            newstr1+=newstr[i];

        str = newstr1;
        delete [] newstr;
        std::cout << "sorted input data after replacing: " << str << std::endl;
    }
    return us;
}

int CountSum(std::string &str) {
    int sum = 0;
    constexpr int kStartPosition = 0;
    constexpr int kStep = 3;

    for (int i = kStartPosition; i < str.size(); i++) {
        if ((str[i]<='9')&&(str[i]>='0'))
            sum += (str[i] - '0');
    }
    std::cout << "\nsum = " << sum << std::endl;
    return sum;
}

void Op_1(Buffer<std::string> &buffer) {
    std::string str;
    while (std::cin >> str) {

        if (!CheckInput(str)) {
            continue;
        }
        buffer.Push(str);
    }
}

void Op_2(Buffer<std::string> &buffer) {
    Server server(AF_INET, SOCK_STREAM, 8080);
    server.CreateListener();

    if (!server.BindAddress()) {
        return;
    }

    server.AcceptSocket();

    std::string str;
    int sum = 0;
    try {
        while (true) {
            // pop string from buffer
            str = buffer.Pop();

            std::cout << "\ndata for calculating the sum of digits: " << str << std::endl;

            sum = 0;
            sum = CountSum(str);

            // send sum to program 2
            server.SendMessage(std::to_string(sum).c_str());

        }
    } catch (std::runtime_error &error) {
        std::cout << error.what() << std::endl;
        server.Close();
    }
}

int main() {
    Buffer<std::string> buffer("data.txt");
    std::thread thread_1(Op_1, std::ref(buffer));
    std::thread thread_2(Op_2, std::ref(buffer));

    thread_1.join();
    thread_2.join();

    return 0;
}
