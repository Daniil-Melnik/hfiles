#include <netinet/in.h>

#include <iostream>
#include <cstring>
#include <string>

#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>


class Client {
public:
    Client(int domain, int type, int port);

    ~Client();

    int GetMessage(char *data, int size);

    int CreateSocket();
    int GetSocket() const;

    bool ConnectToAddress();
    bool ConnectToAddress(sockaddr_in &address);

    int AcceptSocket();

private:
    sockaddr_in s_address;
    int listener_;
    int sock_client;
    int s_domain;
    int s_type;
    int s_port;
};

Client::Client(int domain, int type, int port) :
        s_domain(domain), s_type(type), s_port(port)
{}

Client::~Client() {
    close(sock_client);
}

int Client::GetMessage(char *data, int size) {
    return recv(sock_client, (void *)data, size, 0);
}

int Client::CreateSocket() {
    sock_client = socket(s_domain, s_type, 0);
    if(sock_client < 0) {
        std::cerr << "Error (socket)" << std::endl;
        return 1;
    }
    return sock_client;
}

int Client::GetSocket() const {
    return sock_client;
}

bool Client::ConnectToAddress() {
    s_address.sin_family = s_domain;
    s_address.sin_port = htons(s_port);
    s_address.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if(connect(sock_client, (sockaddr *)&s_address, sizeof(s_address)) < 0) {
        std::cerr << "Error (connect)" << std::endl;
        return false;
    }
    return true;
}

bool Client::ConnectToAddress(sockaddr_in &address)
{
    s_address.sin_family = address.sin_family;
    s_address.sin_port = address.sin_port;
    s_address.sin_addr.s_addr = address.sin_addr.s_addr;

    if(connect(sock_client, (sockaddr *)&s_address, sizeof(s_address)) < 0) {
        std::cerr << "Error (connect)" << std::endl;
        return false;
    }
    return true;
}


int main() {
    const int messageLimit = 100;
    char message[messageLimit];
    const int port = 8080;
    int n=0;
    Client client(AF_INET, SOCK_STREAM, port);
    client.CreateSocket();

    if (!client.ConnectToAddress()) {
        return 1;
    }

    while (true) {
        int result = client.GetMessage(message, messageLimit);
        while ((message[n]!='\0')&&(message[n]>='0')&&(message[n]<='9'))
            n++;
        message[n]='\0';

        if (result == 0) {
            break;
        }

        if (strlen(message) >= 2 && std::stoi(message) % 32 == 0) {
            std::cout << "received message: " << message << std::endl;
        } else {
            std::cout << "invalid message format" << std::endl;
        }
    }

    return 0;
}
